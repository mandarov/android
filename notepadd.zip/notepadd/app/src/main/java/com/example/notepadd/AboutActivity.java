package com.example.notepadd;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.notepadd.R;

public class AboutActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        TextView authorTextView = findViewById(R.id.authorTextView);
        Button homeButton = findViewById(R.id.homeButton);

        authorTextView.setText("Автор: Иван Иванов\nГруппа: ИВТ-123");

        homeButton.setOnClickListener(v -> finish());
    }
}