package com.example.notepadd;

import java.io.Serializable;

public class Note implements Serializable {
    private int id;
    private String title;
    private String text;
    private String date;

    public Note(int id, String title, String text, String date) {
        this.id = id;
        this.title = title;
        this.text = text;
        this.date = date;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getText() {
        return text;
    }

    public String getDate() {
        return date;
    }
}

