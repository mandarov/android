package com.example.notepadd;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.notepadd.R;
import com.example.notepadd.database.DatabaseHelper;
import com.example.notepadd.models.Note;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ListView listView;
    private TextView selectedTextView;
    private com.example.notepadd.DatabaseHelper databaseHelper;
    private List<com.example.notepadd.Note> notes;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);
        selectedTextView = findViewById(R.id.selectedTextView);

        databaseHelper = new com.example.notepadd.DatabaseHelper(this);
        loadNotes();

        Button addNoteButton = findViewById(R.id.addButton);
        Button aboutButton = findViewById(R.id.aboutButton);
        Button exitButton = findViewById(R.id.exitButton);
        Button deleteButton = findViewById(R.id.deleteButton);

        listView.setOnItemClickListener((parent, view, position, id) -> {
            Note selectedNote = notes.get(position);
            selectedTextView.setText("Выбрано: " + selectedNote.getTitle());
        });

        addNoteButton.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, NotepadActivity.class)));
        aboutButton.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, AboutActivity.class)));
        exitButton.setOnClickListener(v -> finishAffinity());
        deleteButton.setOnClickListener(v -> {
            int selectedIndex = listView.getCheckedItemPosition();
            if (selectedIndex != AdapterView.INVALID_POSITION) {
                Note selectedNote = notes.get(selectedIndex);
                if (databaseHelper.deleteNote(selectedNote.getId())) {
                    Toast.makeText(this, "Запись удалена", Toast.LENGTH_SHORT).show();
                    loadNotes();
                } else {
                    Toast.makeText(this, "Ошибка удаления", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void loadNotes() {
        notes = databaseHelper.getAllNotes();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,
                notes.stream().map(Note::getTitle).toArray(String[]::new));
        listView.setAdapter(adapter);
    }
}